import Link from 'next/link'
import {
  Shield,
  Zap,
  Lock,
  BarChart3,
  Globe,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'

const features = [
  {
    icon: Zap,
    title: 'Instant Analysis',
    description:
      'Get real-time threat assessment in milliseconds. Our AI processes your content instantly.',
  },
  {
    icon: Lock,
    title: 'Privacy First',
    description:
      'Your data stays secure. We analyze content without storing sensitive information.',
  },
  {
    icon: BarChart3,
    title: 'Risk Scoring',
    description:
      'Understand threats with clear risk scores and detailed breakdowns of potential dangers.',
  },
  {
    icon: Globe,
    title: 'URL Scanning',
    description:
      'Check suspicious links before clicking. Detect phishing, malware, and scam websites.',
  },
  {
    icon: AlertTriangle,
    title: 'Text Analysis',
    description:
      'Analyze suspicious emails, messages, and text for social engineering attempts.',
  },
  {
    icon: CheckCircle,
    title: 'Actionable Insights',
    description:
      'Receive clear recommendations on how to handle potential threats safely.',
  },
]

const stats = [
  { value: '10M+', label: 'Threats Detected' },
  { value: '99.9%', label: 'Accuracy Rate' },
  { value: '50ms', label: 'Avg Response Time' },
  { value: '24/7', label: 'Protection' },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-32">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-sm text-primary">
              <Shield className="h-4 w-4" />
              AI-Powered Threat Detection
            </div>

            <h1 className="mx-auto max-w-4xl text-balance text-4xl font-bold tracking-tight text-foreground sm:text-6xl lg:text-7xl">
              Protect Yourself From{' '}
              <span className="text-primary">Online Threats</span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground sm:text-xl">
              Scan suspicious URLs and text content instantly. Our AI detects
              phishing attempts, malware, and social engineering attacks before
              they can harm you.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button asChild size="lg" className="gap-2">
                <Link href="/signup">
                  Start Scanning Free
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/pricing">View Pricing</Link>
              </Button>
            </div>

            <p className="mt-4 text-sm text-muted-foreground">
              3 free scans per day. No credit card required.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border/50 bg-card/30 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-primary sm:text-4xl">
                  {stat.value}
                </div>
                <div className="mt-1 text-sm text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 sm:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Comprehensive Threat Protection
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
              Our AI-powered platform provides multiple layers of protection to
              keep you safe from evolving cyber threats.
            </p>
          </div>

          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group rounded-xl border border-border/50 bg-card/50 p-6 transition-all hover:border-primary/30 hover:bg-card"
              >
                <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3 text-primary">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 sm:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-background to-accent/10 px-6 py-16 sm:px-12 sm:py-20">
            <div className="relative z-10 text-center">
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Ready to Stay Protected?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                Join thousands of users who trust CyberAI to protect them from
                online threats. Start with 3 free scans daily.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button asChild size="lg" className="gap-2">
                  <Link href="/signup">
                    Create Free Account
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/analyzer">Try Demo</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
