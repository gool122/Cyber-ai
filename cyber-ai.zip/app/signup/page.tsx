import { Metadata } from 'next'
import { AuthForm } from '@/components/auth-form'

export const metadata: Metadata = {
  title: 'Create Account',
  description: 'Create your CyberAI account to start scanning threats',
}

export default function SignupPage() {
  return <AuthForm mode="signup" />
}
