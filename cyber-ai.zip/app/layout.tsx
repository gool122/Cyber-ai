import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'sonner'
import './globals.css'

const geist = Geist({ 
  subsets: ['latin'],
  variable: '--font-geist-sans',
})
const geistMono = Geist_Mono({ 
  subsets: ['latin'],
  variable: '--font-geist-mono',
})

export const metadata: Metadata = {
  title: {
    default: 'CyberAI - AI-Powered Threat Detection',
    template: '%s | CyberAI',
  },
  description: 'Protect yourself from phishing, malware, and online threats with AI-powered analysis. Scan suspicious URLs and text content instantly.',
  keywords: ['cybersecurity', 'phishing detection', 'malware scanner', 'threat analysis', 'AI security'],
  authors: [{ name: 'CyberAI' }],
  openGraph: {
    title: 'CyberAI - AI-Powered Threat Detection',
    description: 'Protect yourself from phishing, malware, and online threats with AI-powered analysis.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#0a0f1a',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geist.variable} ${geistMono.variable} bg-background`}>
      <body className="font-sans antialiased min-h-screen">
        {children}
        <Toaster position="top-right" theme="dark" />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
