import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { users, scans } from '@/lib/db/schema'
import { eq, desc, count, and, gte } from 'drizzle-orm'
import { DashboardNav } from '@/components/dashboard-nav'
import { DashboardContent } from './dashboard-content'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'View your scan history and account overview',
}

export default async function DashboardPage() {
  const session = await auth()

  if (!session?.user?.id) {
    redirect('/login')
  }

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, session.user.id))
    .limit(1)

  if (!user) {
    redirect('/login')
  }

  // Get recent scans
  const recentScans = await db
    .select()
    .from(scans)
    .where(eq(scans.userId, session.user.id))
    .orderBy(desc(scans.createdAt))
    .limit(10)

  // Get stats
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const [totalScansResult] = await db
    .select({ count: count() })
    .from(scans)
    .where(eq(scans.userId, session.user.id))

  const [todayScansResult] = await db
    .select({ count: count() })
    .from(scans)
    .where(
      and(
        eq(scans.userId, session.user.id),
        gte(scans.createdAt, today)
      )
    )

  const [threatsDetectedResult] = await db
    .select({ count: count() })
    .from(scans)
    .where(
      and(
        eq(scans.userId, session.user.id),
        eq(scans.result, 'dangerous')
      )
    )

  const stats = {
    totalScans: totalScansResult?.count || 0,
    todayScans: todayScansResult?.count || 0,
    threatsDetected: threatsDetectedResult?.count || 0,
    tier: user.tier,
    scansRemaining: user.tier === 'pro' ? 'Unlimited' : String(Math.max(0, 3 - (user.scanCount || 0))),
  }

  return (
    <div className="min-h-screen">
      <DashboardNav userName={session.user.name} />
      <main className="pt-24 pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <DashboardContent
            stats={stats}
            recentScans={recentScans}
            userName={session.user.name || 'User'}
          />
        </div>
      </main>
    </div>
  )
}
