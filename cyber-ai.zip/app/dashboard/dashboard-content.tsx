'use client'

import Link from 'next/link'
import {
  Shield,
  Search,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowRight,
  TrendingUp,
  Activity,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import type { Scan } from '@/lib/db/schema'
import { formatDistanceToNow } from 'date-fns'

interface DashboardContentProps {
  stats: {
    totalScans: number
    todayScans: number
    threatsDetected: number
    tier: string
    scansRemaining: string
  }
  recentScans: Scan[]
  userName: string
}

const resultConfig = {
  safe: {
    icon: CheckCircle,
    color: 'text-safe',
    bg: 'bg-safe/10',
    label: 'Safe',
  },
  suspicious: {
    icon: AlertTriangle,
    color: 'text-suspicious',
    bg: 'bg-suspicious/10',
    label: 'Suspicious',
  },
  dangerous: {
    icon: Shield,
    color: 'text-dangerous',
    bg: 'bg-dangerous/10',
    label: 'Dangerous',
  },
}

export function DashboardContent({
  stats,
  recentScans,
  userName,
}: DashboardContentProps) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
            Welcome back, {userName.split(' ')[0]}
          </h1>
          <p className="mt-1 text-muted-foreground">
            {"Here's an overview of your security activity"}
          </p>
        </div>
        <Button asChild className="gap-2">
          <Link href="/analyzer">
            <Search className="h-4 w-4" />
            New Scan
          </Link>
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-border/50 bg-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Scans
            </CardTitle>
            <Activity className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.totalScans}
            </div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Today&apos;s Scans
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.todayScans}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.scansRemaining} remaining today
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Threats Detected
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-dangerous" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {stats.threatsDetected}
            </div>
            <p className="text-xs text-muted-foreground">Blocked dangers</p>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Account Tier
            </CardTitle>
            <Shield className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold capitalize text-foreground">
                {stats.tier}
              </span>
              {stats.tier === 'free' && (
                <Link href="/pricing">
                  <Badge variant="outline" className="cursor-pointer hover:bg-primary/10">
                    Upgrade
                  </Badge>
                </Link>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.tier === 'pro' ? 'Unlimited scans' : '3 scans/day'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Scans */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Scans</CardTitle>
          {recentScans.length > 0 && (
            <Button variant="ghost" size="sm" asChild>
              <Link href="/analyzer" className="gap-1">
                View All
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {recentScans.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Search className="mb-4 h-12 w-12 text-muted-foreground/50" />
              <h3 className="mb-2 text-lg font-medium text-foreground">
                No scans yet
              </h3>
              <p className="mb-4 text-sm text-muted-foreground">
                Start by scanning a suspicious URL or text
              </p>
              <Button asChild>
                <Link href="/analyzer">Start Scanning</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {recentScans.map((scan) => {
                const config = resultConfig[scan.result as keyof typeof resultConfig]
                const Icon = config.icon

                return (
                  <div
                    key={scan.id}
                    className="flex items-center gap-4 rounded-lg border border-border/50 bg-background/50 p-4"
                  >
                    <div className={`rounded-lg p-2 ${config.bg}`}>
                      <Icon className={`h-5 w-5 ${config.color}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {scan.contentType.toUpperCase()}
                        </Badge>
                        <Badge className={`${config.bg} ${config.color} border-0`}>
                          {config.label}
                        </Badge>
                      </div>
                      <p className="mt-1 truncate text-sm text-muted-foreground">
                        {scan.content}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {scan.createdAt
                        ? formatDistanceToNow(new Date(scan.createdAt), {
                            addSuffix: true,
                          })
                        : 'Unknown'}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
