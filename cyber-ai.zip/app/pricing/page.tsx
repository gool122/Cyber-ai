import { Metadata } from 'next'
import Link from 'next/link'
import { Check, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'

export const metadata: Metadata = {
  title: 'Pricing',
  description: 'Choose the plan that fits your security needs',
}

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Perfect for occasional security checks',
    features: [
      { text: '3 scans per day', included: true },
      { text: 'URL analysis', included: true },
      { text: 'Text analysis', included: true },
      { text: 'Basic threat detection', included: true },
      { text: 'Scan history (7 days)', included: true },
      { text: 'Priority support', included: false },
      { text: 'API access', included: false },
      { text: 'Team features', included: false },
    ],
    cta: 'Get Started Free',
    href: '/signup',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '$9',
    period: 'per month',
    description: 'For individuals who need comprehensive protection',
    features: [
      { text: 'Unlimited scans', included: true },
      { text: 'URL analysis', included: true },
      { text: 'Text analysis', included: true },
      { text: 'Advanced threat detection', included: true },
      { text: 'Unlimited scan history', included: true },
      { text: 'Priority support', included: true },
      { text: 'API access', included: true },
      { text: 'Team features', included: false },
    ],
    cta: 'Upgrade to Pro',
    href: '/signup?plan=pro',
    highlighted: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'contact sales',
    description: 'For organizations with advanced security needs',
    features: [
      { text: 'Everything in Pro', included: true },
      { text: 'Custom integrations', included: true },
      { text: 'Dedicated account manager', included: true },
      { text: 'SLA guarantee', included: true },
      { text: 'On-premise deployment', included: true },
      { text: 'Advanced analytics', included: true },
      { text: 'Unlimited API calls', included: true },
      { text: 'Team management', included: true },
    ],
    cta: 'Contact Sales',
    href: '#',
    highlighted: false,
  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-32 pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center">
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl">
              Simple, Transparent Pricing
            </h1>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
              Choose the plan that fits your security needs. Start free and
              upgrade as you grow.
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="mt-16 grid gap-8 lg:grid-cols-3">
            {plans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative border-border/50 bg-card/50 ${
                  plan.highlighted
                    ? 'border-primary/50 ring-2 ring-primary/20'
                    : ''
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="rounded-full bg-primary px-4 py-1 text-xs font-semibold text-primary-foreground">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-foreground">
                      {plan.price}
                    </span>
                    <span className="text-muted-foreground">
                      {' '}
                      / {plan.period}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {plan.description}
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li
                        key={feature.text}
                        className="flex items-center gap-3"
                      >
                        {feature.included ? (
                          <Check className="h-4 w-4 shrink-0 text-safe" />
                        ) : (
                          <X className="h-4 w-4 shrink-0 text-muted-foreground/50" />
                        )}
                        <span
                          className={
                            feature.included
                              ? 'text-sm text-foreground'
                              : 'text-sm text-muted-foreground/50'
                          }
                        >
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    asChild
                    className="w-full"
                    variant={plan.highlighted ? 'default' : 'outline'}
                  >
                    <Link href={plan.href}>{plan.cta}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* FAQ Section */}
          <div className="mt-20">
            <h2 className="text-center text-2xl font-bold text-foreground">
              Frequently Asked Questions
            </h2>
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              <div className="rounded-xl border border-border/50 bg-card/50 p-6">
                <h3 className="font-semibold text-foreground">
                  How accurate is the threat detection?
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Our AI-powered analysis achieves 99.9% accuracy in detecting
                  known phishing, malware, and scam patterns. We continuously
                  update our detection algorithms.
                </p>
              </div>
              <div className="rounded-xl border border-border/50 bg-card/50 p-6">
                <h3 className="font-semibold text-foreground">
                  Can I upgrade or downgrade anytime?
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Yes! You can change your plan at any time. Upgrades take
                  effect immediately, and downgrades apply at the end of your
                  billing cycle.
                </p>
              </div>
              <div className="rounded-xl border border-border/50 bg-card/50 p-6">
                <h3 className="font-semibold text-foreground">
                  Is my data kept private?
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Absolutely. We analyze content in real-time and do not store
                  sensitive data. Your scan history is encrypted and only
                  accessible to you.
                </p>
              </div>
              <div className="rounded-xl border border-border/50 bg-card/50 p-6">
                <h3 className="font-semibold text-foreground">
                  What payment methods do you accept?
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  We accept all major credit cards, PayPal, and bank transfers
                  for Enterprise plans. All payments are processed securely.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
