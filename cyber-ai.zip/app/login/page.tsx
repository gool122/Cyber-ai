import { Metadata } from 'next'
import { AuthForm } from '@/components/auth-form'

export const metadata: Metadata = {
  title: 'Sign In',
  description: 'Sign in to your CyberAI account',
}

export default function LoginPage() {
  return <AuthForm mode="login" />
}
